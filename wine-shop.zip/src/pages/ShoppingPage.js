function ShoppingPage() {
  return (
    <div className="container">
      <h2 className="text-center">Shopping</h2>
      <p className="text-center">TBD</p>
    </div>
  );
}

export default ShoppingPage;
